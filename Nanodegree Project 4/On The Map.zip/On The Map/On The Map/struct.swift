//
//  struct.swift
//  On The Map
//
//  Created by Douglas Cooper on 5/9/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

struct globals {
    static var firstName = "firstNamePlaceholder"
    static var lastName = "lastNamePlaceholder"
    static var accountKey = "keyPlaceholder"
}
