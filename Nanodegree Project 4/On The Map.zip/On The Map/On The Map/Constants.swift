//
//  Constants.swift
//  On The Map
//
//  Created by Douglas Cooper on 2/8/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

import Foundation

struct Constants {
    <#fields#>
}
