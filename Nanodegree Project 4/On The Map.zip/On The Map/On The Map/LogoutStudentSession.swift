//
//  LogoutStudentSession.swift
//  On The Map
//
//  Created by Douglas Cooper on 5/5/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

import Foundation
