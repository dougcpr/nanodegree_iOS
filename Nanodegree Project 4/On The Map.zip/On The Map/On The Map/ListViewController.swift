//
//  ListViewController.swift
//  On The Map
//
//  Created by Douglas Cooper on 4/25/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

import UIKit

class listViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
}
