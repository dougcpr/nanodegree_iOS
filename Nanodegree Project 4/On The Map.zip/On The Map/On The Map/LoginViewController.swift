//
//  ViewController.swift
//  On The Map
//
//  Created by Douglas Cooper on 2/7/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func registrationButton(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.udacity.com/account/auth#!/signup")!, completionHandler: nil)
    }

    @IBAction func loginButtonPressed(_ sender: Any) {
        verifyUser(username: userNameTextField.text ?? String(), password: passwordTextField.text ?? String())
        }
}
