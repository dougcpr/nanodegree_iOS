//
//  InformationPostingViewController.swift
//  On The Map
//
//  Created by Douglas Cooper on 5/1/17.
//  Copyright © 2017 Douglas Cooper. All rights reserved.
//

import UIKit
import CoreLocation

class InformationPostingViewController: UIViewController {
    
    @IBOutlet weak var onTheMapTextField: UITextField!
    @IBOutlet weak var findOnTheMap: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let background = UIColor (colorLiteralRed: 0, green: 100, blue: 77.6, alpha: 1)
        
        findOnTheMap.backgroundColor = background
        findOnTheMap.layer.cornerRadius = 10
        findOnTheMap.layer.borderWidth = 1
        findOnTheMap.layer.borderColor = UIColor.clear.cgColor

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func CancelPinPost(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let tabBarViewController = storyBoard.instantiateViewController(withIdentifier: "TabBarViewController")
        self.present(tabBarViewController, animated: true, completion: nil)
    }
    
    @IBAction func findOnTheMap(_ sender: Any) {
        let address = onTheMapTextField.text ?? String()
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let linkViewController = storyBoard.instantiateViewController(withIdentifier: "SetupLinkController") as! PostLinkViewController
        linkViewController.address = address
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                self.alertIncorrectAddress()
            }
            if let placemark = placemarks?.first {
                linkViewController.latitude = (placemark.location?.coordinate.latitude)!
                linkViewController.longitude = (placemark.location?.coordinate.longitude)!
                self.present(linkViewController, animated: true, completion: nil)
            }
        })
    }
    
    func alertIncorrectAddress() {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Incorrect Address", message:
                "Please try again.", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

