//
//  ViewController.swift
//  MemeMeApp
//
//  Created by Douglas Cooper on 9/20/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

import UIKit

class MemeMeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate{
    
    // Outlets
    @IBOutlet weak var toolbar: UIToolbar!
    @IBOutlet weak var imageSelectionView: UIImageView!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var topTextField: UITextField!
    
    //Share Button is an outline to make working with constraints easier
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    var memedImage: UIImage!
    var memes: [Meme]!
    
    let editTextFieldDelegate = textFieldDelegate()
    
    // Lifecycle Declarations
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTextFields(topTextField)
        configureTextFields(bottomTextField)
    }
    
    override func viewWillAppear(animated: Bool) {
        // Disable Camera Button if not Available
        cameraButton.enabled = UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        if imageSelectionView.image == nil {
            shareButton.enabled = false
        } else {
            shareButton.enabled = true
        }
        // Subscribe to keybaord notifications
        self.subscribeToKeyboardNotifications()
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        // Unsubscribe from keyboard notifications
        self.unsubscribeFromKeyboardNotifications()
    }
    
    // Start of IB Actions
    // Select an image from the album y setting a temporary variable
    // to a picker controller and selects the source type as the photo library
    @IBAction func pickImageFromSource(source: UIImagePickerControllerSourceType) {
        
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        
        // created a switch into the UISourceType by looking into the library
        switch source {
        case .Camera:
            // Select an Image from the Camera and sets up an image picker with a temporary variable
            // sets the source type to a camera and presents a view controller according to the src type
            pickerController.sourceType = .Camera
            presentViewController(pickerController, animated: true, completion: nil)
        // Becauase the Album is a Custom class I set it to a default use. The source type is not being 
        // affected in the IBAction. When I click Album Button, it only sends the UIImagePickerControllerSourceType
        default:
            pickerController.sourceType = .PhotoLibrary
            presentViewController(pickerController, animated: true, completion: nil)
            break
        }
    }
 
    
    // action to generate a memed image that is returned and pass it into the activity item
    @IBAction func shareButtonPressed(sender: AnyObject) {
        // memed image to activity view
        self.memedImage = generateMemedImage()
        let activityVC = UIActivityViewController(activityItems: [self.memedImage!], applicationActivities: nil)
        // Save image to shared
        activityVC.completionWithItemsHandler = {activity, completed, items, error in
            if completed {
                self.save()
                self.dismissViewControllerAnimated(true, completion: nil)
            }
        }
        self.presentViewController(activityVC, animated: true, completion: nil)
    }
    
    // Start of Applicaiton Functions
    // Show image in image view
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            imageSelectionView.image = image
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    // Canceled image selection
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    // Shifting view when keyboard covers text field
    
    // Subscribe to keyboard notifications. It will add an observer to the keyboardWillShow function
    // when the keyboardwill show is invoked the height will affect the View Controller
    func subscribeToKeyboardNotifications() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(MemeMeViewController.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(MemeMeViewController.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    // Unsubscribe from keybaord notitfications It will add an observer to the keyboardWillHide function
    // when the keyboardwill show is invoked the height will affect the View Controller
    func unsubscribeFromKeyboardNotifications() {
        NSNotificationCenter.defaultCenter().removeObserver(self, name:
            UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name:
            UIKeyboardWillHideNotification, object: nil)
    }
    // Get and use keyboard height. This sets the keyboard height to negative because
    // when the screen rotates the lifecycle will subscribe again.
    // using -= will shift it up a second time, so you have to multiply by negative 1 to 
    // keep the height consistent distance from the origin
    func keyboardWillShow(notification: NSNotification) {
        if bottomTextField.isFirstResponder() {
            view.frame.origin.y = getKeyboardHeight(notification) * (-1)
        }
    }
    
    // sets teh height to 0 or the origin
    func keyboardWillHide(notification: NSNotification) {
        if bottomTextField.isFirstResponder() {
            view.frame.origin.y = 0
        }
    }
    
    // gets the keyboard height by looking at the observable
    // returns the keyboard's height
    func getKeyboardHeight(notification: NSNotification) -> CGFloat {
        let userInfo = notification.userInfo!
        let keyboardSize = userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.CGRectValue().height
    }
    
    // sets a structure to be called later, if
    struct Meme {
        
        var topTextField: String?
        var bottomTextField: String?
        var originalImage: UIImage?
        let memedImage: UIImage!
    }
    
    func save() {
        _ = Meme(topTextField: topTextField.text!, bottomTextField: bottomTextField.text!, originalImage: imageSelectionView.image!, memedImage: memedImage)
    }
    
    // Hides the toolbar, no nav bar is necessary and looks cleaner to have everything on one bar
    func generateMemedImage() -> UIImage {
        
        toolbar.hidden = true
        UIGraphicsBeginImageContext(self.view.frame.size)
        self.view.drawViewHierarchyInRect(self.view.frame, afterScreenUpdates: true)
        let memedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        toolbar.hidden = false
        
        return memedImage
    }
    
    
    func configureTextFields(textField: UITextField) {
        
        // Controlls the text Attributes when the view loads
        // Talks about color, font, and size
        let memeTextAttributes = [
            NSForegroundColorAttributeName : UIColor.whiteColor(),
            NSStrokeColorAttributeName : UIColor.blackColor(),
            NSFontAttributeName : UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSStrokeWidthAttributeName : -3.0
        ]
        
        // Delegates responsibility to hitting return key
        // and begining editing
        textField.defaultTextAttributes = memeTextAttributes
        textField.textAlignment = .Center
        textField.delegate = editTextFieldDelegate
        bottomTextField.text = "BOTTOM"
        topTextField.text = "TOP"
    }

    

    
}

