//
//  SelectImageDelegate.swift
//  MemeMeApp
//
//  Created by Douglas Cooper on 10/15/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

import UIKit

class SelectImageDelegate:  NSObject, UIImagePickerControllerDelegate{
    selectImage.delegate = self
}