//
//  MemeCollectionViewCell.swift
//  MemeMe App 2.0
//
//  Created by Douglas Cooper on 11/4/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var memedImageView: UIImageView!
}
