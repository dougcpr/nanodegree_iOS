//
//  PlaySoundsViewController.swift
//  PitchPerfect
//
//  Created by Douglas Cooper on 8/22/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {
    
    //setting up outlets to the buttons
    @IBOutlet weak var darthVaderButton: UIButton!
    @IBOutlet weak var chipmunkButton: UIButton!
    @IBOutlet weak var echoButton: UIButton!
    @IBOutlet weak var rabbitButton: UIButton!
    @IBOutlet weak var reverbButton: UIButton!
    @IBOutlet weak var snailButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    
    //outlets created for the views to handle the axis control
    @IBOutlet weak var outerStackView: UIStackView!
    @IBOutlet weak var innerStackView1: UIStackView!
    @IBOutlet weak var innerStackView2: UIStackView!
    @IBOutlet weak var innerStackView3: UIStackView!
    @IBOutlet weak var innerStackView4: UIStackView!
    
    var recordedAudioURL: NSURL!
    var audioFile: AVAudioFile!
    var audioEngine: AVAudioEngine!
    var audioPlayerNode: AVAudioPlayerNode!
    var stopTimer: NSTimer!
    
    //function to alter the axis of the stack view when the view is portrait or landscape
    func setStackViewLayout() {
        //using let makes this immuatble going two functions in to effect the status bar orientation
        let orientation = UIApplication.sharedApplication().statusBarOrientation
        
        if orientation.isPortrait{
            self.outerStackView.axis = .Vertical
            self.setInnerStackViewsAxis(.Horizontal)
        } else {
            self.outerStackView.axis = .Horizontal
            self.setInnerStackViewsAxis(.Vertical)
        }
    }
    
    func setInnerStackViewsAxis(axisStyle: UILayoutConstraintAxis)  {
        self.innerStackView1.axis = axisStyle
        self.innerStackView2.axis = axisStyle
        self.innerStackView3.axis = axisStyle
        self.innerStackView4.axis = axisStyle
    }
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        coordinator.animateAlongsideTransition({ (context) -> Void in
            self.setStackViewLayout()
            }, completion: nil)
    }

    
    //defines each element as an Int
    enum ButtonType: Int { case Slow = 0, Fast, Chipmunk, Vader, Echo, Reverb}

    //takes the tag in in UIButton and sends it into the switch argument
    @IBAction func playSoundForButton(sender: UIButton){
        print("Play Sound Button Pressed")
        
        switch (ButtonType(rawValue: sender.tag)!) {
        case .Slow:
            playSound(rate: 0.5)
        case .Fast:
            playSound(rate: 1.5)
        case .Chipmunk:
            playSound(pitch: 1000)
        case .Vader:
            playSound(pitch: -1000)
        case .Echo:
            playSound(echo: true)
        case .Reverb:
            playSound(reverb: true)

        }
        
        configureUI(.Playing)
    }
    
    //stops audio if the button is pressed
    @IBAction func stopButtonPressed(sender: AnyObject){
        print("Stop Audio Button Pressed")
        stopAudio()
    }

    //checks if the view did load before setting up the audio
    override func viewDidLoad() {
        super.viewDidLoad()
        print("PlaySoundsViewController loaded")
        setupAudio()
        print("Audio setup done")
        setStackViewLayout()
    }

    override func viewWillAppear(animated: Bool) {
        configureUI(.NotPlaying)
    }

}
