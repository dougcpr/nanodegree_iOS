//
//  RecordSoundsViewController.swift
//  PitchPerfect
//
//  Created by Douglas Cooper on 8/20/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

//import the classes to control the UI Views you setup
//also AVFoundation will be in charge of AV Audio Session Management
import UIKit
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {
    
    var audioRecorder:AVAudioRecorder!
    
    //establishing outlets to the UI, these are connected to the images and text in the view
    @IBOutlet weak var recordLabel: UILabel!
    @IBOutlet weak var stopRecording: UIButton!
    @IBOutlet weak var record: UIButton!

    @IBAction func recordButton(sender: UIButton) {
        print("Record.")
        toggleButton()

        
        //a constant controller to setup the directory path as a string
        //most likely some predetermined argument function from what was imported in AVFoundation
        let dirPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)[0] as String
        //setting up a name for recording and designating it as a wav file
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        //i am assuming this constructs the file path by using the array determined above
        //and prints the file for confirmation to debug properly
        let filePath = NSURL.fileURLWithPathComponents(pathArray)
        print(filePath)
        
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        
        try! audioRecorder = AVAudioRecorder(URL: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecordingButton(sender: UIButton) {
        print("Stop Recording.")
        audioRecorder.stop()
        toggleButton()
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
    override func viewWillAppear(animated: Bool) {
        stopRecording.enabled = false
    }
    
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
        print("AV Audio Recording Finished")
        if (flag) {
        self.performSegueWithIdentifier("stopRecording", sender : audioRecorder.url)
        } else {
            print("Saving failed...")
        }
        
    }
    
    //by placing the features in abstracted methods you delegate the work to these functions
    //this is to control the flow of the program. In case this needed to be called again, we we can call the function
    //instead of repeating code
    func toggleButton(){
        if (stopRecording.enabled == false){
            stopRecording.enabled = true
            record.enabled = true
            recordLabel.text = "Tap to Record"
        } else {
            stopRecording.enabled = true
            record.enabled = false
            recordLabel.text = "Recording..."
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "stopRecording") {
            let playSoundsVC = segue.destinationViewController as! PlaySoundsViewController
            let recordedAudioURL = sender as! NSURL
            playSoundsVC.recordedAudioURL = recordedAudioURL
        }
    }
}

