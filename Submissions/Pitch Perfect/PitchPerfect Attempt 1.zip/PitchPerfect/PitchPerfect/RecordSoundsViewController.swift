//
//  RecordSoundsViewController.swift
//  PitchPerfect
//
//  Created by Douglas Cooper on 8/20/16.
//  Copyright © 2016 Douglas Cooper. All rights reserved.
//

//import the classes to control the UI Views you setup
//also AVFoundation will be in charge of AV Audio Session Management
import UIKit
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {
    
    var audioRecorder:AVAudioRecorder!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //establishing outlets to the UI, these are connected to the images and text in the view
    @IBOutlet weak var recordLabel: UILabel!
    @IBOutlet weak var stopRecording: UIButton!
    @IBOutlet weak var record: UIButton!

    @IBAction func recordButton(sender: UIButton) {
        print("Record.")
        recordLabel.text = "Recording..."
        stopRecording.enabled = true
        record.enabled = false
        
        //a constant controller to setup the directory path as a string
        //most likely some predetermined argument function from what was imported in AVFoundation
        let dirPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)[0] as String
        //setting up a name for recording and designating it as a wav file
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        //i am assuming this constructs the file path by using the array determined above
        //and prints the file for confirmation to debug properly
        let filePath = NSURL.fileURLWithPathComponents(pathArray)
        print(filePath)
        
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        
        try! audioRecorder = AVAudioRecorder(URL: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecordingButton(sender: UIButton) {
        print("Stop Recording.")
        recordLabel.text = "Tap to Record"
        stopRecording.enabled = false
        record.enabled = true
        
        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
    override func viewWillAppear(animated: Bool) {
        stopRecording.enabled = false
    }
    
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
        print("AV Audio Recording Finished")
        if (flag) {
        self.performSegueWithIdentifier("stopRecording", sender : audioRecorder.url)
        } else {
            print("Saving failed...")
        }
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "stopRecording") {
            let playSoundsVC = segue.destinationViewController as! PlaySoundsViewController
            let recordedAudioURL = sender as! NSURL
            playSoundsVC.recordedAudioURL = recordedAudioURL
        }
    }
}

